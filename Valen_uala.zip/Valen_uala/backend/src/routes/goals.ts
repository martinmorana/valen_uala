import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../config/database';
import { authenticateToken, requireRole } from '../middleware/auth';

const router = Router();

const goalSchema = z.object({
  title: z.string().min(1),
  targetAmount: z.number().positive(),
  deadline: z.string().optional(),
});

// Create goal
router.post('/', authenticateToken, requireRole(['JUNIOR']), async (req: any, res) => {
  try {
    const data = goalSchema.parse(req.body);
    
    const result = await pool.query(
      `INSERT INTO goals (junior_id, title, target_amount, deadline, status)
       VALUES ($1, $2, $3, $4, 'ACTIVE')
       RETURNING *`,
      [req.user.userId, data.title, data.targetAmount, data.deadline || null]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create goal error:', error);
    res.status(400).json({ error: 'Failed to create goal' });
  }
});

// Get user goals
router.get('/me', authenticateToken, requireRole(['JUNIOR']), async (req: any, res) => {
  try {
    const goals = await pool.query(
      'SELECT * FROM goals WHERE junior_id = $1 ORDER BY created_at DESC',
      [req.user.userId]
    );

    res.json(goals.rows);
  } catch (error) {
    console.error('Get goals error:', error);
    res.status(500).json({ error: 'Failed to fetch goals' });
  }
});

// Update goal progress
router.patch('/:id', authenticateToken, requireRole(['JUNIOR']), async (req: any, res) => {
  try {
    const { id } = req.params;
    const { savedAmount, status } = req.body;

    let updateQuery = 'UPDATE goals SET updated_at = CURRENT_TIMESTAMP';
    const values = [id, req.user.userId];
    let paramCount = 2;

    if (savedAmount !== undefined) {
      updateQuery += `, saved_amount = $${++paramCount}`;
      values.push(savedAmount);
    }

    if (status) {
      updateQuery += `, status = $${++paramCount}`;
      values.push(status);
    }

    updateQuery += ' WHERE id = $1 AND junior_id = $2 RETURNING *';

    const result = await pool.query(updateQuery, values);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Goal not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update goal error:', error);
    res.status(400).json({ error: 'Failed to update goal' });
  }
});

export { router as goalRoutes };
