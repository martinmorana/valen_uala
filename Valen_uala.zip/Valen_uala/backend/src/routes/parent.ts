import { Router } from 'express';
import { pool } from '../config/database';
import { authenticateToken, requireRole } from '../middleware/auth';

const router = Router();

// Get dashboard data
router.get('/dashboard', authenticateToken, requireRole(['PARENT']), async (req: any, res) => {
  try {
    const { juniorId } = req.query;

    // Verify parent-junior link
    const link = await pool.query(
      'SELECT * FROM parent_links WHERE parent_id = $1 AND junior_id = $2 AND status = $3',
      [req.user.userId, juniorId, 'ACTIVE']
    );

    if (link.rows.length === 0) {
      return res.status(403).json({ error: 'No access to this junior account' });
    }

    // Get junior info
    const junior = await pool.query(
      'SELECT id, display_name, email FROM users WHERE id = $1',
      [juniorId]
    );

    // Get recent missions
    const missions = await pool.query(
      `SELECT m.title, mp.status, mp.score, mp.updated_at
       FROM mission_progress mp
       JOIN missions m ON mp.mission_id = m.id
       WHERE mp.junior_id = $1
       ORDER BY mp.updated_at DESC
       LIMIT 10`,
      [juniorId]
    );

    // Get active goals
    const goals = await pool.query(
      'SELECT * FROM goals WHERE junior_id = $1 AND status = $2',
      [juniorId, 'ACTIVE']
    );

    // Get current points
    const points = await pool.query(
      'SELECT total_points FROM user_points WHERE user_id = $1',
      [juniorId]
    );

    // Get recent redemptions
    const redemptions = await pool.query(
      `SELECT r.*, mi.name as item_name, r.created_at
       FROM redemptions r
       JOIN marketplace_items mi ON r.item_id = mi.id
       WHERE r.junior_id = $1
       ORDER BY r.created_at DESC
       LIMIT 5`,
      [juniorId]
    );

    res.json({
      junior: junior.rows[0],
      missions: missions.rows,
      goals: goals.rows,
      points: points.rows[0]?.total_points || 0,
      redemptions: redemptions.rows,
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard data' });
  }
});

// Get linked juniors
router.get('/juniors', authenticateToken, requireRole(['PARENT']), async (req: any, res) => {
  try {
    const juniors = await pool.query(
      `SELECT u.id, u.display_name, u.email, pl.created_at as linked_at
       FROM parent_links pl
       JOIN users u ON pl.junior_id = u.id
       WHERE pl.parent_id = $1 AND pl.status = 'ACTIVE'`,
      [req.user.userId]
    );

    res.json(juniors.rows);
  } catch (error) {
    console.error('Get juniors error:', error);
    res.status(500).json({ error: 'Failed to fetch linked juniors' });
  }
});

export { router as parentRoutes };
