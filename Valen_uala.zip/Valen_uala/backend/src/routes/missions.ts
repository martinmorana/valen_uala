import { Router } from 'express';
import { pool } from '../config/database';
import { authenticateToken, requireRole } from '../middleware/auth';

const router = Router();

// Get missions for current week
router.get('/', authenticateToken, async (req: any, res) => {
  try {
    const { week } = req.query;
    const currentWeek = week || new Date().toISOString().slice(0, 4) + '-' + 
      String(Math.ceil((new Date().getTime() - new Date(new Date().getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000))).padStart(2, '0');

    const missions = await pool.query(
      `SELECT m.*, mp.status as progress_status, mp.score
       FROM missions m
       LEFT JOIN mission_progress mp ON m.id = mp.mission_id AND mp.junior_id = $1
       WHERE m.week = $2 AND m.active = true
       ORDER BY m.difficulty, m.created_at`,
      [req.user.userId, currentWeek]
    );

    res.json(missions.rows);
  } catch (error) {
    console.error('Get missions error:', error);
    res.status(500).json({ error: 'Failed to fetch missions' });
  }
});

// Start mission
router.post('/:id/progress', authenticateToken, requireRole(['JUNIOR']), async (req: any, res) => {
  try {
    const { id } = req.params;
    const { action, evidenceUrl, score } = req.body;

    let status = 'IN_PROGRESS';
    let updateFields = 'status = $3, updated_at = CURRENT_TIMESTAMP';
    let values = [id, req.user.userId, status];

    if (action === 'complete') {
      status = 'DONE';
      if (evidenceUrl) {
        updateFields += ', evidence_url = $4';
        values.push(evidenceUrl);
      }
      if (score !== undefined) {
        updateFields += `, score = $${values.length + 1}`;
        values.push(score);
      }
    }

    const result = await pool.query(
      `INSERT INTO mission_progress (mission_id, junior_id, status, evidence_url, score, started_at)
       VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
       ON CONFLICT (mission_id, junior_id) 
       DO UPDATE SET ${updateFields}
       RETURNING *`,
      [id, req.user.userId, status, evidenceUrl || null, score || 0]
    );

    // Award points if completed
    if (status === 'DONE') {
      const mission = await pool.query('SELECT points FROM missions WHERE id = $1', [id]);
      if (mission.rows.length > 0) {
        await pool.query(
          `UPDATE user_points 
           SET total_points = total_points + $1, updated_at = CURRENT_TIMESTAMP
           WHERE user_id = $2`,
          [mission.rows[0].points, req.user.userId]
        );
      }
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Mission progress error:', error);
    res.status(500).json({ error: 'Failed to update mission progress' });
  }
});

// Get user badges
router.get('/badges/me', authenticateToken, async (req: any, res) => {
  try {
    const badges = await pool.query(
      `SELECT b.*, ub.earned_at
       FROM badges b
       JOIN user_badges ub ON b.id = ub.badge_id
       WHERE ub.user_id = $1
       ORDER BY ub.earned_at DESC`,
      [req.user.userId]
    );

    res.json(badges.rows);
  } catch (error) {
    console.error('Get badges error:', error);
    res.status(500).json({ error: 'Failed to fetch badges' });
  }
});

export { router as missionRoutes };
