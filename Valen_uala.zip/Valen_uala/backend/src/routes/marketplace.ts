import { Router } from 'express';
import { pool } from '../config/database';
import { authenticateToken, requireRole } from '../middleware/auth';
import { v4 as uuidv4 } from 'uuid';

const router = Router();

// Get catalog
router.get('/catalog', authenticateToken, async (req, res) => {
  try {
    const items = await pool.query(
      `SELECT mi.*, p.name as partner_name, p.category
       FROM marketplace_items mi
       JOIN partners p ON mi.partner_id = p.id
       WHERE mi.active = true AND p.active = true
       ORDER BY mi.points_cost ASC`
    );

    res.json(items.rows);
  } catch (error) {
    console.error('Get catalog error:', error);
    res.status(500).json({ error: 'Failed to fetch catalog' });
  }
});

// Redeem item
router.post('/redeem/:itemId', authenticateToken, requireRole(['JUNIOR']), async (req: any, res) => {
  try {
    const { itemId } = req.params;

    // Check user points
    const userPoints = await pool.query(
      'SELECT total_points FROM user_points WHERE user_id = $1',
      [req.user.userId]
    );

    if (userPoints.rows.length === 0) {
      return res.status(404).json({ error: 'User points not found' });
    }

    // Check item availability
    const item = await pool.query(
      'SELECT * FROM marketplace_items WHERE id = $1 AND active = true',
      [itemId]
    );

    if (item.rows.length === 0) {
      return res.status(404).json({ error: 'Item not found' });
    }

    const itemData = item.rows[0];
    const currentPoints = userPoints.rows[0].total_points;

    if (currentPoints < itemData.points_cost) {
      return res.status(400).json({ error: 'Insufficient points' });
    }

    if (itemData.stock <= 0) {
      return res.status(400).json({ error: 'Item out of stock' });
    }

    // Generate redemption code
    const redemptionCode = Math.random().toString(36).substring(2, 12).toUpperCase();

    // Create redemption and update points/stock
    await pool.query('BEGIN');

    const redemption = await pool.query(
      `INSERT INTO redemptions (item_id, junior_id, points_spent, code, status)
       VALUES ($1, $2, $3, $4, 'ISSUED')
       RETURNING *`,
      [itemId, req.user.userId, itemData.points_cost, redemptionCode]
    );

    await pool.query(
      'UPDATE user_points SET total_points = total_points - $1 WHERE user_id = $2',
      [itemData.points_cost, req.user.userId]
    );

    await pool.query(
      'UPDATE marketplace_items SET stock = stock - 1 WHERE id = $1',
      [itemId]
    );

    await pool.query('COMMIT');

    res.json({
      redemption: redemption.rows[0],
      item: itemData,
    });
  } catch (error) {
    await pool.query('ROLLBACK');
    console.error('Redeem error:', error);
    res.status(500).json({ error: 'Failed to redeem item' });
  }
});

// Get redemption history
router.get('/redeem/history', authenticateToken, requireRole(['JUNIOR']), async (req: any, res) => {
  try {
    const history = await pool.query(
      `SELECT r.*, mi.name as item_name, mi.image_url, p.name as partner_name
       FROM redemptions r
       JOIN marketplace_items mi ON r.item_id = mi.id
       JOIN partners p ON mi.partner_id = p.id
       WHERE r.junior_id = $1
       ORDER BY r.created_at DESC`,
      [req.user.userId]
    );

    res.json(history.rows);
  } catch (error) {
    console.error('Get history error:', error);
    res.status(500).json({ error: 'Failed to fetch redemption history' });
  }
});

export { router as marketplaceRoutes };
