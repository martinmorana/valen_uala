import { Router } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { pool } from '../config/database';
import { v4 as uuidv4 } from 'uuid';

const router = Router();

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(['JUNIOR', 'PARENT', 'ADMIN']),
  displayName: z.string().min(1),
  birthDate: z.string().optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

// Register
router.post('/register', async (req, res) => {
  try {
    const data = registerSchema.parse(req.body);
    const hashedPassword = await bcrypt.hash(data.password, 10);
    
    const result = await pool.query(
      `INSERT INTO users (email, password_hash, role, display_name, birth_date) 
       VALUES ($1, $2, $3, $4, $5) RETURNING id, email, role, display_name`,
      [data.email, hashedPassword, data.role, data.displayName, data.birthDate || null]
    );

    // Initialize points for junior users
    if (data.role === 'JUNIOR') {
      await pool.query(
        'INSERT INTO user_points (user_id, total_points) VALUES ($1, 0)',
        [result.rows[0].id]
      );
    }

    const token = jwt.sign(
      { userId: result.rows[0].id, role: data.role },
      process.env.JWT_SECRET!,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      user: result.rows[0],
      token,
    });
  } catch (error) {
    console.error('Register error:', error);
    res.status(400).json({ error: 'Registration failed' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const data = loginSchema.parse(req.body);
    
    const result = await pool.query(
      'SELECT id, email, password_hash, role, display_name FROM users WHERE email = $1',
      [data.email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = result.rows[0];
    const validPassword = await bcrypt.compare(data.password, user.password_hash);

    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { userId: user.id, role: user.role },
      process.env.JWT_SECRET!,
      { expiresIn: '24h' }
    );

    res.json({
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        displayName: user.display_name,
      },
      token,
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(400).json({ error: 'Login failed' });
  }
});

// Generate parent link code
router.post('/invite-parent', async (req, res) => {
  try {
    const { juniorId } = req.body;
    const inviteCode = Math.random().toString(36).substring(2, 10).toUpperCase();
    
    await pool.query(
      `INSERT INTO parent_links (junior_id, status, invite_code) 
       VALUES ($1, 'PENDING', $2)
       ON CONFLICT (junior_id) DO UPDATE SET invite_code = $2, status = 'PENDING'`,
      [juniorId, inviteCode]
    );

    res.json({ inviteCode });
  } catch (error) {
    console.error('Invite parent error:', error);
    res.status(400).json({ error: 'Failed to generate invite code' });
  }
});

// Accept parent link
router.post('/accept-link', async (req, res) => {
  try {
    const { parentId, inviteCode } = req.body;
    
    const result = await pool.query(
      `UPDATE parent_links 
       SET parent_id = $1, status = 'ACTIVE' 
       WHERE invite_code = $2 AND status = 'PENDING'
       RETURNING junior_id`,
      [parentId, inviteCode]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Invalid or expired invite code' });
    }

    res.json({ success: true, juniorId: result.rows[0].junior_id });
  } catch (error) {
    console.error('Accept link error:', error);
    res.status(400).json({ error: 'Failed to accept link' });
  }
});

export { router as authRoutes };
