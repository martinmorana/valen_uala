import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../config/database';
import { authenticateToken, requireRole } from '../middleware/auth';

const router = Router();

const missionSchema = z.object({
  title: z.string().min(1),
  type: z.enum(['QUIZ', 'HABIT', 'SIMULATION']),
  points: z.number().positive(),
  difficulty: z.enum(['E', 'M', 'D']),
  week: z.string(),
  contentMarkdown: z.string().optional(),
});

const partnerSchema = z.object({
  name: z.string().min(1),
  category: z.string().min(1),
  contact: z.string().optional(),
});

// Missions CRUD
router.get('/missions', authenticateToken, requireRole(['ADMIN']), async (req, res) => {
  try {
    const missions = await pool.query(
      'SELECT * FROM missions ORDER BY week DESC, created_at DESC'
    );
    res.json(missions.rows);
  } catch (error) {
    console.error('Get missions error:', error);
    res.status(500).json({ error: 'Failed to fetch missions' });
  }
});

router.post('/missions', authenticateToken, requireRole(['ADMIN']), async (req, res) => {
  try {
    const data = missionSchema.parse(req.body);
    
    const result = await pool.query(
      `INSERT INTO missions (title, type, points, difficulty, week, content_markdown)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [data.title, data.type, data.points, data.difficulty, data.week, data.contentMarkdown || '']
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create mission error:', error);
    res.status(400).json({ error: 'Failed to create mission' });
  }
});

router.put('/missions/:id', authenticateToken, requireRole(['ADMIN']), async (req, res) => {
  try {
    const { id } = req.params;
    const data = missionSchema.parse(req.body);
    
    const result = await pool.query(
      `UPDATE missions 
       SET title = $1, type = $2, points = $3, difficulty = $4, week = $5, content_markdown = $6
       WHERE id = $7
       RETURNING *`,
      [data.title, data.type, data.points, data.difficulty, data.week, data.contentMarkdown || '', id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Mission not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update mission error:', error);
    res.status(400).json({ error: 'Failed to update mission' });
  }
});

// Partners CRUD
router.get('/partners', authenticateToken, requireRole(['ADMIN']), async (req, res) => {
  try {
    const partners = await pool.query(
      'SELECT * FROM partners ORDER BY name'
    );
    res.json(partners.rows);
  } catch (error) {
    console.error('Get partners error:', error);
    res.status(500).json({ error: 'Failed to fetch partners' });
  }
});

router.post('/partners', authenticateToken, requireRole(['ADMIN']), async (req, res) => {
  try {
    const data = partnerSchema.parse(req.body);
    
    const result = await pool.query(
      'INSERT INTO partners (name, category, contact) VALUES ($1, $2, $3) RETURNING *',
      [data.name, data.category, data.contact || '']
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create partner error:', error);
    res.status(400).json({ error: 'Failed to create partner' });
  }
});

// Analytics
router.get('/analytics', authenticateToken, requireRole(['ADMIN']), async (req, res) => {
  try {
    const stats = await Promise.all([
      pool.query('SELECT COUNT(*) as total_users FROM users'),
      pool.query('SELECT COUNT(*) as total_juniors FROM users WHERE role = $1', ['JUNIOR']),
      pool.query('SELECT COUNT(*) as total_parents FROM users WHERE role = $1', ['PARENT']),
      pool.query('SELECT COUNT(*) as active_links FROM parent_links WHERE status = $1', ['ACTIVE']),
      pool.query('SELECT COUNT(*) as completed_missions FROM mission_progress WHERE status = $1', ['DONE']),
      pool.query('SELECT COUNT(*) as total_redemptions FROM redemptions'),
    ]);

    res.json({
      totalUsers: parseInt(stats[0].rows[0].total_users),
      totalJuniors: parseInt(stats[1].rows[0].total_juniors),
      totalParents: parseInt(stats[2].rows[0].total_parents),
      activeLinks: parseInt(stats[3].rows[0].active_links),
      completedMissions: parseInt(stats[4].rows[0].completed_missions),
      totalRedemptions: parseInt(stats[5].rows[0].total_redemptions),
    });
  } catch (error) {
    console.error('Analytics error:', error);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

export { router as adminRoutes };
