import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { authRoutes } from './routes/auth';
import { missionRoutes } from './routes/missions';
import { goalRoutes } from './routes/goals';
import { marketplaceRoutes } from './routes/marketplace';
import { parentRoutes } from './routes/parent';
import { adminRoutes } from './routes/admin';
import { errorHandler } from './middleware/errorHandler';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Routes
app.use('/auth', authRoutes);
app.use('/missions', missionRoutes);
app.use('/goals', goalRoutes);
app.use('/marketplace', marketplaceRoutes);
app.use('/parent', parentRoutes);
app.use('/admin', adminRoutes);

// Root route
app.get('/', (req, res) => {
  res.json({ 
    message: 'Ualá Junior Plus API',
    version: '1.0.0',
    endpoints: {
      health: '/health',
      auth: '/auth/*',
      missions: '/missions/*',
      goals: '/goals/*',
      marketplace: '/marketplace/*',
      parent: '/parent/*',
      admin: '/admin/*'
    }
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Error handling
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`🚀 Ualá Junior API running on port ${PORT}`);
});
