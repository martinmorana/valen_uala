import React, { useState, useEffect } from 'react';

function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [user, setUser] = useState(null);
  const [error, setError] = useState('');
  const [analytics, setAnalytics] = useState(null);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:3000/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
      
      const data = await response.json();
      
      if (response.ok && data.user.role === 'ADMIN') {
        setUser(data.user);
        localStorage.setItem('admin_token', data.token);
        setError('');
        fetchAnalytics(data.token);
      } else {
        setError('Access denied. Admin role required.');
      }
    } catch (err) {
      setError('Connection error');
    }
  };

  const fetchAnalytics = async (token) => {
    try {
      const response = await fetch('http://localhost:3000/admin/analytics', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        setAnalytics(data);
      }
    } catch (err) {
      console.error('Failed to fetch analytics:', err);
    }
  };

  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    if (token) {
      // Auto-login if token exists
      fetchAnalytics(token);
    }
  }, []);

  if (user) {
    return (
      <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif', background: '#f5f5f5', minHeight: '100vh' }}>
        <div style={{ background: 'white', padding: '20px', borderRadius: '8px', marginBottom: '20px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
          <h1 style={{ color: '#7c3aed', margin: '0 0 10px 0' }}>Ualá Admin Panel</h1>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <p style={{ margin: '0', color: '#666' }}>Bienvenido, {user.displayName}</p>
            </div>
            <button 
              onClick={() => {
                setUser(null);
                localStorage.removeItem('admin_token');
              }}
              style={{ 
                background: '#dc3545', 
                color: 'white', 
                border: 'none', 
                padding: '8px 16px', 
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Cerrar Sesión
            </button>
          </div>
        </div>

        {analytics && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '20px' }}>
            <div style={{ background: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
              <h3 style={{ margin: '0 0 10px 0', color: '#3b82f6' }}>Total Usuarios</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', margin: '0', color: '#333' }}>{analytics.totalUsers}</p>
            </div>
            <div style={{ background: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
              <h3 style={{ margin: '0 0 10px 0', color: '#10b981' }}>Usuarios Junior</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', margin: '0', color: '#333' }}>{analytics.totalJuniors}</p>
            </div>
            <div style={{ background: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
              <h3 style={{ margin: '0 0 10px 0', color: '#7c3aed' }}>Padres/Tutores</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', margin: '0', color: '#333' }}>{analytics.totalParents}</p>
            </div>
            <div style={{ background: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
              <h3 style={{ margin: '0 0 10px 0', color: '#f59e0b' }}>Vínculos Activos</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', margin: '0', color: '#333' }}>{analytics.activeLinks}</p>
            </div>
            <div style={{ background: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
              <h3 style={{ margin: '0 0 10px 0', color: '#6366f1' }}>Misiones Completadas</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', margin: '0', color: '#333' }}>{analytics.completedMissions}</p>
            </div>
            <div style={{ background: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
              <h3 style={{ margin: '0 0 10px 0', color: '#ec4899' }}>Canjes Realizados</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', margin: '0', color: '#333' }}>{analytics.totalRedemptions}</p>
            </div>
          </div>
        )}

        <div style={{ background: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
          <h3 style={{ margin: '0 0 15px 0' }}>Funcionalidades disponibles:</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '15px' }}>
            <div style={{ padding: '15px', border: '1px solid #e5e7eb', borderRadius: '6px' }}>
              <h4 style={{ margin: '0 0 10px 0', color: '#7c3aed' }}>✅ Dashboard</h4>
              <p style={{ margin: '0', fontSize: '14px', color: '#666' }}>Estadísticas generales funcionando</p>
            </div>
            <div style={{ padding: '15px', border: '1px solid #e5e7eb', borderRadius: '6px' }}>
              <h4 style={{ margin: '0 0 10px 0', color: '#7c3aed' }}>✅ API Conectada</h4>
              <p style={{ margin: '0', fontSize: '14px', color: '#666' }}>Endpoints admin operativos</p>
            </div>
            <div style={{ padding: '15px', border: '1px solid #e5e7eb', borderRadius: '6px' }}>
              <h4 style={{ margin: '0 0 10px 0', color: '#f59e0b' }}>🔄 Gestión Misiones</h4>
              <p style={{ margin: '0', fontSize: '14px', color: '#666' }}>CRUD en desarrollo</p>
            </div>
            <div style={{ padding: '15px', border: '1px solid #e5e7eb', borderRadius: '6px' }}>
              <h4 style={{ margin: '0 0 10px 0', color: '#f59e0b' }}>🔄 Gestión Partners</h4>
              <p style={{ margin: '0', fontSize: '14px', color: '#666' }}>CRUD en desarrollo</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%)',
      fontFamily: 'Arial, sans-serif'
    }}>
      <div style={{ 
        background: 'white', 
        padding: '40px', 
        borderRadius: '12px', 
        boxShadow: '0 10px 25px rgba(0,0,0,0.1)',
        width: '100%',
        maxWidth: '400px'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <div style={{ fontSize: '48px', marginBottom: '10px' }}>🛡️</div>
          <h1 style={{ color: '#333', margin: '0 0 10px 0' }}>Ualá Admin Panel</h1>
          <p style={{ color: '#666', margin: '0' }}>Acceso solo para administradores</p>
        </div>
        
        <form onSubmit={handleLogin}>
          {error && (
            <div style={{ 
              background: '#fee2e2', 
              color: '#dc2626', 
              padding: '10px', 
              borderRadius: '4px', 
              marginBottom: '20px',
              border: '1px solid #fecaca'
            }}>
              {error}
            </div>
          )}
          
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{ 
                width: '100%', 
                padding: '12px', 
                border: '1px solid #ddd', 
                borderRadius: '4px',
                fontSize: '16px',
                boxSizing: 'border-box'
              }}
            />
          </div>
          
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Contraseña
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{ 
                width: '100%', 
                padding: '12px', 
                border: '1px solid #ddd', 
                borderRadius: '4px',
                fontSize: '16px',
                boxSizing: 'border-box'
              }}
            />
          </div>
          
          <button 
            type="submit"
            style={{ 
              width: '100%', 
              padding: '12px', 
              background: '#7c3aed', 
              color: 'white', 
              border: 'none', 
              borderRadius: '4px',
              fontSize: '16px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}
          >
            Iniciar Sesión
          </button>
        </form>
        
        <div style={{ 
          marginTop: '30px', 
          padding: '15px', 
          background: '#f8f9fa', 
          borderRadius: '4px',
          fontSize: '14px'
        }}>
          <p style={{ margin: '0', fontWeight: 'bold' }}>Cuenta de prueba:</p>
          <p style={{ margin: '5px 0 0 0' }}>admin@uala.com / password</p>
        </div>
      </div>
    </div>
  );
}

export default App;
