import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Plus, Edit, Trash2, Target } from 'lucide-react';

interface Mission {
  id: string;
  title: string;
  type: 'QUIZ' | 'HABIT' | 'SIMULATION';
  points: number;
  difficulty: 'E' | 'M' | 'D';
  week: string;
  content_markdown: string;
  active: boolean;
  created_at: string;
}

export default function Missions() {
  const [missions, setMissions] = useState<Mission[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingMission, setEditingMission] = useState<Mission | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    type: 'QUIZ' as const,
    points: 100,
    difficulty: 'E' as const,
    week: '',
    contentMarkdown: '',
  });

  useEffect(() => {
    fetchMissions();
  }, []);

  const fetchMissions = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/admin/missions`);
      setMissions(response.data);
    } catch (error) {
      console.error('Error fetching missions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingMission) {
        await axios.put(`${process.env.REACT_APP_API_URL}/admin/missions/${editingMission.id}`, formData);
      } else {
        await axios.post(`${process.env.REACT_APP_API_URL}/admin/missions`, formData);
      }
      
      setShowForm(false);
      setEditingMission(null);
      setFormData({
        title: '',
        type: 'QUIZ',
        points: 100,
        difficulty: 'E',
        week: '',
        contentMarkdown: '',
      });
      fetchMissions();
    } catch (error) {
      console.error('Error saving mission:', error);
    }
  };

  const handleEdit = (mission: Mission) => {
    setEditingMission(mission);
    setFormData({
      title: mission.title,
      type: mission.type,
      points: mission.points,
      difficulty: mission.difficulty,
      week: mission.week,
      contentMarkdown: mission.content_markdown || '',
    });
    setShowForm(true);
  };

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'E': return 'Fácil';
      case 'M': return 'Medio';
      case 'D': return 'Difícil';
      default: return difficulty;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'QUIZ': return 'Quiz';
      case 'HABIT': return 'Hábito';
      case 'SIMULATION': return 'Simulación';
      default: return type;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Cargando misiones...</div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Misiones</h1>
          <p className="mt-2 text-gray-600">
            Gestiona las misiones educativas para usuarios junior
          </p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          Nueva Misión
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              {editingMission ? 'Editar Misión' : 'Nueva Misión'}
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Título</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Tipo</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="QUIZ">Quiz</option>
                  <option value="HABIT">Hábito</option>
                  <option value="SIMULATION">Simulación</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Puntos</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={formData.points}
                    onChange={(e) => setFormData({ ...formData, points: parseInt(e.target.value) })}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Dificultad</label>
                  <select
                    value={formData.difficulty}
                    onChange={(e) => setFormData({ ...formData, difficulty: e.target.value as any })}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
                  >
                    <option value="E">Fácil</option>
                    <option value="M">Medio</option>
                    <option value="D">Difícil</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Semana (YYYY-WW)</label>
                <input
                  type="text"
                  required
                  placeholder="2024-45"
                  value={formData.week}
                  onChange={(e) => setFormData({ ...formData, week: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Contenido (Markdown)</label>
                <textarea
                  rows={4}
                  value={formData.contentMarkdown}
                  onChange={(e) => setFormData({ ...formData, contentMarkdown: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
                />
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    setEditingMission(null);
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700"
                >
                  {editingMission ? 'Actualizar' : 'Crear'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {missions.map((mission) => (
            <li key={mission.id}>
              <div className="px-4 py-4 flex items-center justify-between">
                <div className="flex items-center">
                  <Target className="h-5 w-5 text-purple-500 mr-3" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">{mission.title}</p>
                    <p className="text-sm text-gray-500">
                      {getTypeLabel(mission.type)} • {getDifficultyLabel(mission.difficulty)} • {mission.points} pts • Semana {mission.week}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    mission.active 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {mission.active ? 'Activa' : 'Inactiva'}
                  </span>
                  <button
                    onClick={() => handleEdit(mission)}
                    className="text-purple-600 hover:text-purple-900"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
