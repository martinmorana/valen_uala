import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Users, UserCheck, Target, ShoppingCart, TrendingUp, Award } from 'lucide-react';

interface Analytics {
  totalUsers: number;
  totalJuniors: number;
  totalParents: number;
  activeLinks: number;
  completedMissions: number;
  totalRedemptions: number;
}

export default function Dashboard() {
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/admin/analytics`);
      setAnalytics(response.data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Cargando estadísticas...</div>
      </div>
    );
  }

  const stats = [
    {
      name: 'Total Usuarios',
      value: analytics?.totalUsers || 0,
      icon: Users,
      color: 'bg-blue-500',
    },
    {
      name: 'Usuarios Junior',
      value: analytics?.totalJuniors || 0,
      icon: UserCheck,
      color: 'bg-green-500',
    },
    {
      name: 'Padres/Tutores',
      value: analytics?.totalParents || 0,
      icon: Users,
      color: 'bg-purple-500',
    },
    {
      name: 'Vínculos Activos',
      value: analytics?.activeLinks || 0,
      icon: TrendingUp,
      color: 'bg-yellow-500',
    },
    {
      name: 'Misiones Completadas',
      value: analytics?.completedMissions || 0,
      icon: Target,
      color: 'bg-indigo-500',
    },
    {
      name: 'Canjes Realizados',
      value: analytics?.totalRedemptions || 0,
      icon: ShoppingCart,
      color: 'bg-pink-500',
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="mt-2 text-gray-600">
          Resumen general de la plataforma Ualá Junior Plus
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className={`${stat.color} rounded-md p-3`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        {stat.name}
                      </dt>
                      <dd className="text-3xl font-bold text-gray-900">
                        {stat.value.toLocaleString()}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Engagement Metrics */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Métricas de Engagement</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Tasa de vinculación</span>
              <span className="text-sm font-medium">
                {analytics?.activeLinks && analytics?.totalJuniors 
                  ? Math.round((analytics.activeLinks / analytics.totalJuniors) * 100)
                  : 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Misiones por usuario</span>
              <span className="text-sm font-medium">
                {analytics?.completedMissions && analytics?.totalJuniors
                  ? Math.round(analytics.completedMissions / analytics.totalJuniors * 10) / 10
                  : 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Canjes por usuario</span>
              <span className="text-sm font-medium">
                {analytics?.totalRedemptions && analytics?.totalJuniors
                  ? Math.round(analytics.totalRedemptions / analytics.totalJuniors * 10) / 10
                  : 0}
              </span>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Acciones Rápidas</h3>
          <div className="space-y-3">
            <button className="w-full text-left px-4 py-2 text-sm text-purple-600 hover:bg-purple-50 rounded-lg transition-colors">
              Crear nueva misión
            </button>
            <button className="w-full text-left px-4 py-2 text-sm text-purple-600 hover:bg-purple-50 rounded-lg transition-colors">
              Agregar partner
            </button>
            <button className="w-full text-left px-4 py-2 text-sm text-purple-600 hover:bg-purple-50 rounded-lg transition-colors">
              Exportar reportes
            </button>
            <button className="w-full text-left px-4 py-2 text-sm text-purple-600 hover:bg-purple-50 rounded-lg transition-colors">
              Configurar campaña
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
