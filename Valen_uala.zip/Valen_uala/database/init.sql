-- Ualá Junior Plus Database Schema
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role VARCHAR(10) NOT NULL CHECK (role IN ('JUNIOR', 'PARENT', 'ADMIN')),
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password_hash VARCHAR(255) NOT NULL,
    birth_date DATE,
    display_name VARCHAR(100) NOT NULL,
    locale VARCHAR(10) DEFAULT 'es-AR',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Parent-Junior links
CREATE TABLE parent_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    junior_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    parent_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(10) NOT NULL CHECK (status IN ('PENDING', 'ACTIVE', 'REVOKED')),
    invite_code VARCHAR(8) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(junior_id, parent_id)
);

-- Partners
CREATE TABLE partners (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    contact VARCHAR(255),
    agreement_url VARCHAR(500),
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Missions
CREATE TABLE missions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(200) NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('QUIZ', 'HABIT', 'SIMULATION')),
    points INTEGER NOT NULL DEFAULT 100,
    difficulty VARCHAR(1) NOT NULL CHECK (difficulty IN ('E', 'M', 'D')),
    week VARCHAR(7) NOT NULL, -- YYYY-WW format
    content_markdown TEXT,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Mission Progress
CREATE TABLE mission_progress (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    mission_id UUID NOT NULL REFERENCES missions(id) ON DELETE CASCADE,
    junior_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(15) NOT NULL CHECK (status IN ('ASSIGNED', 'IN_PROGRESS', 'DONE', 'VERIFIED')),
    evidence_url VARCHAR(500),
    score INTEGER DEFAULT 0,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(mission_id, junior_id)
);

-- Badges
CREATE TABLE badges (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    criteria VARCHAR(500) NOT NULL,
    icon VARCHAR(100),
    points_required INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User Badges (earned)
CREATE TABLE user_badges (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    badge_id UUID NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, badge_id)
);

-- Goals (Savings goals)
CREATE TABLE goals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    junior_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    target_amount INTEGER NOT NULL,
    saved_amount INTEGER DEFAULT 0,
    deadline DATE,
    status VARCHAR(15) NOT NULL CHECK (status IN ('ACTIVE', 'COMPLETED', 'CANCELLED')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Marketplace Items
CREATE TABLE marketplace_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id UUID NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    points_cost INTEGER NOT NULL,
    stock INTEGER DEFAULT 0,
    terms TEXT,
    image_url VARCHAR(500),
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Redemptions
CREATE TABLE redemptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    item_id UUID NOT NULL REFERENCES marketplace_items(id),
    junior_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    points_spent INTEGER NOT NULL,
    code VARCHAR(20) NOT NULL,
    status VARCHAR(10) NOT NULL CHECK (status IN ('ISSUED', 'REDEEMED')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User Points (current balance)
CREATE TABLE user_points (
    user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    total_points INTEGER DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notifications
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    channel VARCHAR(10) NOT NULL CHECK (channel IN ('PUSH', 'EMAIL')),
    title VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    status VARCHAR(10) NOT NULL CHECK (status IN ('SENT', 'READ')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Audit Log
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50),
    resource_id UUID,
    details JSONB,
    ip_address INET,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_parent_links_junior ON parent_links(junior_id);
CREATE INDEX idx_parent_links_parent ON parent_links(parent_id);
CREATE INDEX idx_mission_progress_junior ON mission_progress(junior_id);
CREATE INDEX idx_mission_progress_mission ON mission_progress(mission_id);
CREATE INDEX idx_goals_junior ON goals(junior_id);
CREATE INDEX idx_redemptions_junior ON redemptions(junior_id);
CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);

-- Seed data (password: "password" hashed with bcrypt)
INSERT INTO users (email, password_hash, role, display_name, birth_date) VALUES
('admin@uala.com', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN', 'Admin Ualá', '1990-01-01'),
('parent@test.com', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'PARENT', 'Padre Test', '1985-05-15'),
('junior@test.com', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'JUNIOR', 'Junior Test', '2008-03-20');

INSERT INTO partners (name, category, contact) VALUES
('Librería Ateneo', 'LIBRERIA', 'contacto@ateneo.com'),
('Coursera', 'CURSOS', 'partners@coursera.com'),
('MercadoLibre', 'TECNOLOGIA', 'b2b@mercadolibre.com');

INSERT INTO badges (name, criteria, icon, points_required) VALUES
('Primer Ahorro', 'Completar primera meta de ahorro', '💰', 0),
('Estudiante Dedicado', 'Completar 5 misiones educativas', '📚', 500),
('Ahorrador Experto', 'Ahorrar $10,000 en total', '🏆', 1000);

INSERT INTO missions (title, type, points, difficulty, week, content_markdown) VALUES
('Presupuesto Básico', 'QUIZ', 100, 'E', '2024-45', '# Aprende a hacer un presupuesto\n\n¿Qué es un presupuesto?'),
('Ahorro Semanal', 'HABIT', 150, 'M', '2024-45', '# Desafío: Ahorra $500 esta semana\n\nTips para ahorrar...'),
('Simulador de Compras', 'SIMULATION', 200, 'D', '2024-45', '# Practica decisiones de compra\n\nEscenario: Tienes $1000...');

-- Initialize points for junior user
INSERT INTO user_points (user_id, total_points) 
SELECT id, 500 FROM users WHERE role = 'JUNIOR';

-- Add marketplace items
INSERT INTO marketplace_items (partner_id, name, description, points_cost, stock, image_url) VALUES
((SELECT id FROM partners WHERE name = 'Librería Ateneo'), 'Libro: Finanzas para Jóvenes', 'Guía práctica de educación financiera', 300, 10, 'https://via.placeholder.com/200'),
((SELECT id FROM partners WHERE name = 'Coursera'), 'Curso: Inversiones Básicas', 'Curso online de 4 semanas sobre inversiones', 800, 5, 'https://via.placeholder.com/200'),
((SELECT id FROM partners WHERE name = 'MercadoLibre'), 'Auriculares Bluetooth', 'Auriculares inalámbricos de calidad', 1200, 3, 'https://via.placeholder.com/200');
