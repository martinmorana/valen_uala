import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { User, Target, Trophy, ShoppingCart, LogOut } from 'lucide-react';

interface Junior {
  id: string;
  display_name: string;
  email: string;
  linked_at: string;
}

interface DashboardData {
  junior: any;
  missions: any[];
  goals: any[];
  points: number;
  redemptions: any[];
}

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [juniors, setJuniors] = useState<Junior[]>([]);
  const [selectedJunior, setSelectedJunior] = useState<string>('');
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchJuniors();
  }, []);

  useEffect(() => {
    if (selectedJunior) {
      fetchDashboardData(selectedJunior);
    }
  }, [selectedJunior]);

  const fetchJuniors = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/parent/juniors`);
      setJuniors(response.data);
      if (response.data.length > 0) {
        setSelectedJunior(response.data[0].id);
      }
    } catch (error) {
      console.error('Error fetching juniors:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchDashboardData = async (juniorId: string) => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/parent/dashboard?juniorId=${juniorId}`);
      setDashboardData(response.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Cargando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-purple-600">Ualá Junior Plus</h1>
              <span className="text-gray-500">Panel Parental</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Hola, {user?.displayName}</span>
              <button
                onClick={logout}
                className="flex items-center space-x-1 text-gray-600 hover:text-gray-800"
              >
                <LogOut size={16} />
                <span>Salir</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {juniors.length === 0 ? (
          <div className="text-center py-12">
            <User size={48} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No hay cuentas junior vinculadas
            </h3>
            <p className="text-gray-600 mb-6">
              Vincula la cuenta de tu hijo/a para comenzar a supervisar su progreso financiero.
            </p>
            <Link
              to="/link-junior"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700"
            >
              Vincular cuenta junior
            </Link>
          </div>
        ) : (
          <>
            {/* Junior Selector */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Seleccionar hijo/a:
              </label>
              <select
                value={selectedJunior}
                onChange={(e) => setSelectedJunior(e.target.value)}
                className="block w-full max-w-xs px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
              >
                {juniors.map((junior) => (
                  <option key={junior.id} value={junior.id}>
                    {junior.display_name}
                  </option>
                ))}
              </select>
            </div>

            {dashboardData && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Points Card */}
                <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <Trophy className="h-8 w-8 text-yellow-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Puntos actuales</p>
                      <p className="text-2xl font-bold text-gray-900">{dashboardData.points}</p>
                    </div>
                  </div>
                </div>

                {/* Active Goals */}
                <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <Target className="h-8 w-8 text-green-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Metas activas</p>
                      <p className="text-2xl font-bold text-gray-900">{dashboardData.goals.length}</p>
                    </div>
                  </div>
                </div>

                {/* Recent Redemptions */}
                <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <ShoppingCart className="h-8 w-8 text-blue-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Canjes realizados</p>
                      <p className="text-2xl font-bold text-gray-900">{dashboardData.redemptions.length}</p>
                    </div>
                  </div>
                </div>

                {/* Recent Missions */}
                <div className="md:col-span-2 lg:col-span-3 bg-white rounded-lg shadow">
                  <div className="px-6 py-4 border-b border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900">Actividad reciente</h3>
                  </div>
                  <div className="p-6">
                    {dashboardData.missions.length === 0 ? (
                      <p className="text-gray-500 text-center py-4">No hay actividad reciente</p>
                    ) : (
                      <div className="space-y-4">
                        {dashboardData.missions.slice(0, 5).map((mission, index) => (
                          <div key={index} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
                            <div>
                              <p className="font-medium text-gray-900">{mission.title}</p>
                              <p className="text-sm text-gray-500">
                                {new Date(mission.updated_at).toLocaleDateString('es-AR')}
                              </p>
                            </div>
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              mission.status === 'DONE' 
                                ? 'bg-green-100 text-green-800'
                                : mission.status === 'IN_PROGRESS'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {mission.status === 'DONE' ? 'Completada' : 
                               mission.status === 'IN_PROGRESS' ? 'En progreso' : 'Asignada'}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Goals Progress */}
                {dashboardData.goals.length > 0 && (
                  <div className="md:col-span-2 lg:col-span-3 bg-white rounded-lg shadow">
                    <div className="px-6 py-4 border-b border-gray-200">
                      <h3 className="text-lg font-medium text-gray-900">Metas de ahorro</h3>
                    </div>
                    <div className="p-6">
                      <div className="space-y-4">
                        {dashboardData.goals.map((goal) => (
                          <div key={goal.id} className="border rounded-lg p-4">
                            <div className="flex justify-between items-center mb-2">
                              <h4 className="font-medium text-gray-900">{goal.title}</h4>
                              <span className="text-sm text-gray-500">
                                ${goal.saved_amount} / ${goal.target_amount}
                              </span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-green-500 h-2 rounded-full" 
                                style={{ width: `${Math.min((goal.saved_amount / goal.target_amount) * 100, 100)}%` }}
                              ></div>
                            </div>
                            <p className="text-xs text-gray-500 mt-1">
                              {Math.round((goal.saved_amount / goal.target_amount) * 100)}% completado
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
