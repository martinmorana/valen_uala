import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import { ArrowLeft, Link as LinkIcon } from 'lucide-react';

export default function LinkJunior() {
  const [inviteCode, setInviteCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await axios.post(`${process.env.REACT_APP_API_URL}/auth/accept-link`, {
        parentId: user?.id,
        inviteCode: inviteCode.toUpperCase(),
      });
      
      setSuccess(true);
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Error al vincular cuenta');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full space-y-8 p-8 bg-white rounded-xl shadow-lg text-center">
          <div className="text-green-500">
            <LinkIcon size={48} className="mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900">¡Vinculación exitosa!</h2>
            <p className="mt-2 text-gray-600">
              La cuenta junior ha sido vinculada correctamente.
            </p>
            <p className="mt-4 text-sm text-gray-500">
              Redirigiendo al dashboard...
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center text-purple-600 hover:text-purple-700 mb-6"
        >
          <ArrowLeft size={20} className="mr-2" />
          Volver al dashboard
        </button>

        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="text-center mb-8">
            <LinkIcon size={48} className="mx-auto text-purple-600 mb-4" />
            <h1 className="text-3xl font-bold text-gray-900">Vincular cuenta junior</h1>
            <p className="mt-2 text-gray-600">
              Ingresa el código de invitación que te proporcionó tu hijo/a
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="inviteCode" className="block text-sm font-medium text-gray-700 mb-2">
                Código de invitación
              </label>
              <input
                id="inviteCode"
                type="text"
                required
                value={inviteCode}
                onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                placeholder="Ej: ABC12345"
                className="block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500 text-center text-lg font-mono"
                maxLength={8}
              />
              <p className="mt-2 text-sm text-gray-500">
                El código tiene 8 caracteres y distingue mayúsculas y minúsculas
              </p>
            </div>

            <button
              type="submit"
              disabled={loading || inviteCode.length < 8}
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Vinculando...' : 'Vincular cuenta'}
            </button>
          </form>

          <div className="mt-8 p-4 bg-blue-50 rounded-lg">
            <h3 className="text-sm font-medium text-blue-900 mb-2">¿Cómo obtener el código?</h3>
            <ol className="text-sm text-blue-800 space-y-1">
              <li>1. Tu hijo/a debe abrir la app Ualá Junior</li>
              <li>2. Ir a "Configuración" → "Vincular padre/madre"</li>
              <li>3. Generar código de invitación</li>
              <li>4. Compartir el código contigo</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}
